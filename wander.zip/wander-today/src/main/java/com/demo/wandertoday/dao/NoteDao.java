package com.demo.wandertoday.dao;

import java.util.List;

import com.demo.wandertoday.entity.Note;

public interface NoteDao {
	
	public void save(Note n);

	public List<Note> getAllNotes(String user);

	public Note getById(long id);

	public void delete(long id);

}
