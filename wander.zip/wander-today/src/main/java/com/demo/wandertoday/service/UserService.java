package com.demo.wandertoday.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.demo.wandertoday.entity.CrmUser;
import com.demo.wandertoday.entity.User;

public interface UserService extends UserDetailsService {

    User findByUserName(String userName);

    void save(CrmUser crmUser);
}
