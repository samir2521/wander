package com.demo.wandertoday.controller;

import java.security.Principal;
import java.sql.Timestamp;
import java.time.LocalDateTime;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.demo.wandertoday.entity.CrmUser;
import com.demo.wandertoday.entity.Note;
import com.demo.wandertoday.entity.NoteForm;
import com.demo.wandertoday.entity.User;
import com.demo.wandertoday.service.NoteService;
import com.demo.wandertoday.service.UserService;

@Controller
public class HomeController {
	
	@Autowired
    private UserService userService;
	
	@Autowired
	private NoteService noteService;
	
	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		
		StringTrimmerEditor stringTrimmerEditor = new StringTrimmerEditor(true);
		
		dataBinder.registerCustomEditor(String.class, stringTrimmerEditor);
	}	
	
	@GetMapping("/")
	public String showHomePage(Model m,Principal p){
		
		m.addAttribute("notes",noteService.getAllNotes(p.getName()));
		return "home";
	}
	
	@GetMapping("/showMyLoginPage")
	public String showLoginPage(){
		return "login.html";
	}
	
	@GetMapping("/loginError")
	public String handleLoginError(Model m){
		m.addAttribute("loginError", true);
		return "login.html";
	}
	
	@GetMapping("/logout")
	public String handleLogout(Model m){
		m.addAttribute("logout", true);
		return "login.html";
	}
	
	@GetMapping("/register")
	public String showRegisterationPage(Model m){
		m.addAttribute("crmUser", new CrmUser());
		return "register.html";
	}
	
	@PostMapping("/register/processRegistrationForm")
	public String processRegisteration(@Valid @ModelAttribute("crmUser") CrmUser theCrmUser, 
			BindingResult theBindingResult, 
			Model m) {
		String userName = theCrmUser.getUserName();
		 if (theBindingResult.hasErrors()){
			 return "register.html";
	        }

		// check the database if user already exists
        User existing = userService.findByUserName(userName);
        if (existing != null){
        	m.addAttribute("crmUser", new CrmUser());
			m.addAttribute("registrationError", "User name already exists.");
        	return "registration-form";
        }
     // create user account        						
        userService.save(theCrmUser);  
        m.addAttribute("registerSuccess", true);
        return "login.html";		
	}
	
	@GetMapping("/newNoteForm")
	public String showNewNotePage(Model m){
		m.addAttribute("note", new NoteForm());
		return "add-notes.html";
	}
	
	@PostMapping("/saveNote")
	public String saveNote(@Valid @ModelAttribute("note") NoteForm noteForm, Model m, Principal thePrincipal ){
		Note n;
		if (noteForm.getId() == 0L){
			n =new Note();
			n.setCreatedOn(Timestamp.valueOf(LocalDateTime.now()));
			n.setCreatedByUser(thePrincipal.getName());
		} else {
			n=noteService.getById(noteForm.getId());
		}
		n.setUpdatedByUser(thePrincipal.getName());
		n.setUpdatedOn(Timestamp.valueOf(LocalDateTime.now()));
		n.setTitle(noteForm.getTitle());
		n.setDescription(noteForm.getDescription());
		noteService.save(n);
		m.addAttribute("newNoteCreated", true);
		return "redirect:/";
		
	}
	
	@GetMapping("/updateNote")
	public String getUpdateNote(@RequestParam long id,Model m){
		NoteForm n=new NoteForm();
		Note note=noteService.getById(id);
		if (null == note){
			throw new RuntimeException("not able to fetch Note with Id:" + id);
		}
		n.setId(note.getId());
		n.setTitle(note.getTitle());
		n.setDescription(note.getDescription());
		m.addAttribute("note", n);
		return "add-notes.html";
		
	}
	
	@GetMapping("/deleteNote")
	public String delteNote(@RequestParam long id,Model m){
		noteService.deleteNote(id);
		return "redirect:/";
	}
	
	
}
