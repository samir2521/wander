package com.demo.wandertoday.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.demo.wandertoday.entity.Note;

@Repository
public class NoteDaoImpl implements NoteDao {
	
	@Autowired
	private EntityManager em;

	@Override
	public void save(Note n) {
		// TODO Auto-generated method stub
		em.merge(n);
	}
	
	@Override
	public List<Note> getAllNotes(String user) {
		// TODO Auto-generated method stub
		TypedQuery<Note> q= em.createQuery("from Note where createdByUser=:user order by length(description) desc",Note.class);
		q.setParameter("user", user);
		return q.getResultList();
	}

	@Override
	public Note getById(long id) {
		return em.find(Note.class,id);
		 
	}

	@Override
	public void delete(long id) {
		// TODO Auto-generated method stub
		Note n=em.find(Note.class, id );
		if (null == n){
			throw new RuntimeException("while removing, passed ID is not found:"+ id);
		}
		em.remove(n);
	}

}
