package com.demo.wandertoday.service;

import java.util.List;

import com.demo.wandertoday.entity.Note;

public interface NoteService {
	
	public void save(Note n);
	
	public List<Note> getAllNotes(String user);
	
	public Note getById(long id);

	public void deleteNote(long id);

}
