package com.demo.wandertoday.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.demo.wandertoday.dao.NoteDao;
import com.demo.wandertoday.entity.Note;

@Service
public class NoteServiceImpl implements NoteService {
	
	@Autowired
	private NoteDao noteDao;
	

	@Override
	@Transactional
	public void save(Note n){
		noteDao.save(n);
	}
	
	@Override
	@Transactional
	public List<Note> getAllNotes(String user){
		return noteDao.getAllNotes(user);
	}
	
	@Override
	@Transactional
	public Note getById(long id){
		return noteDao.getById(id);
	}

	@Override
	@Transactional
	public void deleteNote(long id) {
		// TODO Auto-generated method stub
		noteDao.delete(id);
		
	}
}
