package com.demo.wandertoday.dao;

import com.demo.wandertoday.entity.Role;

public interface RoleDao {

	public Role findRoleByName(String theRoleName);
	
}
