package com.demo.wandertoday.dao;

import com.demo.wandertoday.entity.User;

public interface UserDao {

    User findByUserName(String userName);
    
    void save(User user);
    
}
