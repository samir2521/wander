package com.demo.wandertoday.entity;

import javax.validation.constraints.Size;

public class NoteForm {
	
	private long id;
	
	@Size(min=1,max=50,message="title length should be greater than 0 and less than 50")
	private String title;
	
	@Size(max=500,message="description should not be greater than 500")
	private String description;

	public NoteForm() {
		
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	
	
	
	
	
	

}
