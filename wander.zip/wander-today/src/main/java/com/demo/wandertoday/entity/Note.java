package com.demo.wandertoday.entity;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="notes")
public class Note {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column
	private Long id;
	
	@Column
	private String title;
	
	@Column
	private String Description;
	
	@Column(name="created_by_user")
	private String createdByUser;
	
	@Column(name="created_on")
	private Timestamp createdOn;
	
	@Column(name="updated_by_user")
	private String updatedByUser;
	
	@Column(name="updated_on")
	private Timestamp updatedOn;

	public Note() {
		
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return Description;
	}

	public void setDescription(String description) {
		Description = description;
	}

	public String getCreatedByUser() {
		return createdByUser;
	}

	public void setCreatedByUser(String string) {
		this.createdByUser = string;
	}

	public Timestamp getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Timestamp timestamp) {
		this.createdOn = timestamp;
	}

	public String getUpdatedByUser() {
		return updatedByUser;
	}

	public void setUpdatedByUser(String string) {
		this.updatedByUser = string;
	}

	public Timestamp getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Timestamp timestamp) {
		this.updatedOn = timestamp;
	}
	
}
