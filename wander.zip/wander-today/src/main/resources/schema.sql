
DROP TABLE IF EXISTS user;

CREATE TABLE user (
  id int(11) NOT NULL AUTO_INCREMENT,
  username varchar(50) NOT NULL,
  password char(80) NOT NULL,
  first_name varchar(50) NOT NULL,
  last_name varchar(50) NOT NULL,
  email varchar(50) NOT NULL,
  PRIMARY KEY (id)
);

DROP TABLE IF EXISTS role;

CREATE TABLE role (
  id int(11) NOT NULL AUTO_INCREMENT,
  name varchar(50) DEFAULT NULL,
  PRIMARY KEY (id)
);

DROP TABLE IF EXISTS users_roles;

CREATE TABLE users_roles (
  user_id int(11) NOT NULL,
  role_id int(11) NOT NULL,
  
  PRIMARY KEY (user_id,role_id),
  
 
  
  CONSTRAINT FK_USER_05 FOREIGN KEY (user_id) 
  REFERENCES user (id) 
  ON DELETE NO ACTION ON UPDATE NO ACTION,
  
  CONSTRAINT FK_ROLE FOREIGN KEY (role_id) 
  REFERENCES role (id) 
  ON DELETE NO ACTION ON UPDATE NO ACTION
);


DROP TABLE IF EXISTS notes;

CREATE TABLE notes (
  id int(11) NOT NULL AUTO_INCREMENT,
  title varchar(50) NOT NULL,
  description varchar(500),
  created_by_user varchar(50) NOT NULL,
  created_on date NOT NULL,
  updated_by_user varchar(50) NOT NULL,
  updated_on date NOT NULL,
  PRIMARY KEY (id)
);