
INSERT INTO user (username,password,first_name,last_name,email)
VALUES 
('john','$2a$04$eFytJDGtjbThXa80FyOOBuFdK2IwjyWefYkMpiBEFlpBwDH.5PM0K','John','Doe','john@luv2code.com');


INSERT INTO role (name)
VALUES 
('ROLE_EMPLOYEE'),('ROLE_MANAGER'),('ROLE_ADMIN');


INSERT INTO users_roles (user_id,role_id)
VALUES 
(1, 1),
(1, 2),
(1, 3);